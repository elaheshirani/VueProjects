<template>
  <div class="row">
    <app-quote v-for="(item, index) in quotes" v-bind:key="index">{{ item }}</app-quote>
  </div>
</template>

<script>
import Quote from "@/components/Quote";
export default {
  name: "GridQoute",
  props : ['quotes'],
  components : {
    appQuote : Quote
  }
}
</script>

<style scoped>

</style>